package com.doze.timebound;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.WorldEditException;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.entity.Player;
import org.bukkit.generator.structure.Structure;
import org.bukkit.util.BiomeSearchResult;
import org.bukkit.util.StructureSearchResult;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class TimeStructureManager {

    private final Main plugin;
    private final File schematicsFolder;

    public TimeStructureManager(Main plugin) {
        this.plugin = plugin;
        this.schematicsFolder = new File(plugin.getDataFolder(), "schematics");
        if (!schematicsFolder.exists()) {
            schematicsFolder.mkdirs();
        }
    }

    public void generateAll(Player admin) {
        World world = admin.getWorld();
        Location origin = admin.getLocation();

        admin.sendMessage(ChatColor.YELLOW + "Starting background scan for Biomes & Trial Chambers... Please wait!");

        // Run the heavy search asynchronously so the server doesn't freeze!
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {

            // 1. Locate Trial Chamber
            StructureSearchResult brakeSearch = world.locateNearestStructure(origin, Structure.TRIAL_CHAMBERS, 10000, false);
            Location brakeLoc = (brakeSearch != null) ? brakeSearch.getLocation() : null;

            // 2. Locate Snowy Biome
            BiomeSearchResult freezeSearch = world.locateNearestBiome(origin, 10000, Biome.SNOWY_PLAINS, Biome.ICE_SPIKES);
            Location freezeLoc = (freezeSearch != null) ? freezeSearch.getLocation() : null;

            // 3. Locate Desert Biome
            BiomeSearchResult skipSearch = world.locateNearestBiome(origin, 10000, Biome.DESERT);
            Location skipLoc = (skipSearch != null) ? skipSearch.getLocation() : null;

            // 4. Locate Pale Garden Biome (Fallback to Dark Forest)
            BiomeSearchResult reverseSearch = world.locateNearestBiome(origin, 10000, Biome.DARK_FOREST);
            Location reverseLoc = (reverseSearch != null) ? reverseSearch.getLocation() : null;

            // Hop back to the main thread to safely paste using WorldEdit
            Bukkit.getScheduler().runTask(plugin, () -> {

                if (brakeLoc != null) {
                    pasteClock(ClockType.BRAKE, brakeLoc);
                    admin.sendMessage(ChatColor.GREEN + "âœ” Brake Clock generated at Trial Chamber: " + formatLoc(brakeLoc));
                } else {
                    admin.sendMessage(ChatColor.RED + "âœ˜ Could not find a Trial Chamber within 10,000 blocks!");
                }

                if (freezeLoc != null) {
                    Location loc = getHighest(freezeLoc);
                    pasteClock(ClockType.FREEZE, loc);
                    admin.sendMessage(ChatColor.GREEN + "âœ” Freeze Clock generated in Snow Biome: " + formatLoc(loc));
                } else {
                    admin.sendMessage(ChatColor.RED + "âœ˜ Could not find a Snowy biome within 10,000 blocks!");
                }

                if (skipLoc != null) {
                    Location loc = getHighest(skipLoc);
                    pasteClock(ClockType.SKIP, loc);
                    admin.sendMessage(ChatColor.GREEN + "âœ” Skip Clock generated in Desert: " + formatLoc(loc));
                } else {
                    admin.sendMessage(ChatColor.RED + "âœ˜ Could not find a Desert within 10,000 blocks!");
                }

                if (reverseLoc != null) {
                    Location loc = getHighest(reverseLoc);
                    loc.add(0, ThreadLocalRandom.current().nextInt(70, 91), 0); // +70 to 90 blocks high
                    pasteClock(ClockType.REVERSE, loc);
                    admin.sendMessage(ChatColor.GREEN + "âœ” Reverse Clock generated in Pale Garden sky: " + formatLoc(loc));
                } else {
                    admin.sendMessage(ChatColor.RED + "âœ˜ Could not find a Pale Garden within 10,000 blocks!");
                }

                admin.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "Generation Complete!");
            });
        });
    }

    private void pasteClock(ClockType type, Location spawnLoc) {
        String fileName = type.name().toLowerCase() + "clock.schem";
        boolean success = pasteSchematic(fileName, spawnLoc);

        if (success) {
            // Find the carpet and place the hologram!
            Location hologramLoc = findHologramTarget(spawnLoc, type);
            plugin.getClockListener().spawnClickableClock(hologramLoc, type);
        }
    }

    private Location findHologramTarget(Location center, ClockType type) {
        List<Location> carpets = new ArrayList<>();
        int radius = 15;

        // Brake Clock uses GRAY_CARPET, the rest use BLACK_CARPET
        Material targetCarpet = (type == ClockType.BRAKE) ? Material.GRAY_CARPET : Material.BLACK_CARPET;

        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    Location check = center.clone().add(x, y, z);
                    if (check.getBlock().getType() == targetCarpet) {
                        carpets.add(check);
                    }
                }
            }
        }

        if (carpets.isEmpty()) return center.clone().add(0, 2, 0); // Fallback if carpet not found

        // SKIP CLOCK RULE: Hover between the 2 carpets
        if (type == ClockType.SKIP && carpets.size() >= 2) {
            Location c1 = carpets.get(0);
            Location c2 = carpets.get(1);
            double midX = (c1.getX() + c2.getX()) / 2.0;
            double midY = (c1.getY() + c2.getY()) / 2.0;
            double midZ = (c1.getZ() + c2.getZ()) / 2.0;
            return new Location(center.getWorld(), midX + 0.5, midY + 1.5, midZ + 0.5);
        }

        // DEFAULT RULE: 1 block above the single carpet
        return carpets.get(0).clone().add(0.5, 1.5, 0.5);
    }

    private Location getHighest(Location loc) {
        return new Location(loc.getWorld(), loc.getBlockX(), loc.getWorld().getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ()), loc.getBlockZ());
    }

    private String formatLoc(Location loc) {
        return loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }

    private boolean pasteSchematic(String fileName, Location loc) {
        File file = new File(schematicsFolder, fileName);
        if (!file.exists()) {
            plugin.getLogger().warning("Could not find schematic: " + fileName);
            return false;
        }

        ClipboardFormat format = ClipboardFormats.findByFile(file);
        if (format == null) return false;

        try (ClipboardReader reader = format.getReader(new FileInputStream(file))) {
            Clipboard clipboard = reader.read();

            try (EditSession editSession = WorldEdit.getInstance().newEditSession(BukkitAdapter.adapt(loc.getWorld()))) {
                Operation operation = new ClipboardHolder(clipboard)
                        .createPaste(editSession)
                        .to(BlockVector3.at(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()))
                        .ignoreAirBlocks(true)
                        .build();
                Operations.complete(operation);
                return true;
            }
        } catch (IOException | WorldEditException e) {
            e.printStackTrace();
            return false;
        }
    }
}